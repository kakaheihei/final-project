function compute()
{
    p = document.getElementById("principal").value;
    
}
        